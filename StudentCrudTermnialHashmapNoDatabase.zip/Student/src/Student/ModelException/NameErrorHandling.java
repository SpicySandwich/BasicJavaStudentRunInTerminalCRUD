package Student.ModelException;

public class NameErrorHandling extends RuntimeException{

	private static final long serialVersionUID = 1L;
	

	public NameErrorHandling(String message) {
		super(message);
		
	}

	
}
