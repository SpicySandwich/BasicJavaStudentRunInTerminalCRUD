package Student.Validation;

public interface validationInterface {
	
	public String checkname(String name);
	public Integer checkage(Integer age);
	public Integer checkid(Integer id);
	

}
