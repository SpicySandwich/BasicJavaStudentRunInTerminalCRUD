package Student.RunnerMain;

import Student.ExceptionCatcher.ExceptionCatcher;

public class RunStudent {
	
	public static void main(String[] args) {
		
		ExceptionCatcher catcher = new ExceptionCatcher();
		
		catcher.run();

	}

}
