package Student.ModelException;

public class AgeErrorhandling extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public AgeErrorhandling(String message) {
		super(message);
	
	}
	
	

}
